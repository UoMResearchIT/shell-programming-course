#
#  bash functions for controlling date math
#


determine_next_date () {

	local next_year=$( date -d "$3$4$5 $1 $2 day" +%Y )
	local next_month=$( date -d "$3$4$5 $1 $2 day" +%m )
	local next_day=$( date -d "$3$4$5 $1 $2 day" +%d )

	echo $next_year $next_month $next_day

}

increment_dates () {

	if [[ -z $next_year ]]; then 
		read next_year next_month next_day <<< $(determine_next_date $1 $2 $3 $4 $5)
	fi
	curr_year=$next_year
	curr_month=$next_month
	curr_day=$next_day
	read next_year next_month next_day <<< $(determine_next_date $1 $2 $curr_year $curr_month $curr_day)
	
}
