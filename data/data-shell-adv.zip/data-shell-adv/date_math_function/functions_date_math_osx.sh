#
#  bash functions for controlling date math
#


determine_next_date () {

	local next_year=$(date -v ${1}${2}d -j -f "%Y %m %d" "$3 $4 $5" +%Y)
	local next_month=$(date -v ${1}${2}d -j -f "%Y %m %d" "$3 $4 $5" +%m)
	local next_day=$(date -v ${1}${2}d -j -f "%Y %m %d" "$3 $4 $5" +%d)

	echo $next_year $next_month $next_day

}

increment_dates () {

	if [[ -z $next_year ]]; then 
		read next_year next_month next_day <<< $(determine_next_date $1 $2 $3 $4 $5)
	fi
	curr_year=$next_year
	curr_month=$next_month
	curr_day=$next_day
	read next_year next_month next_day <<< $(determine_next_date $1 $2 $curr_year $curr_month $curr_day)
	
}
